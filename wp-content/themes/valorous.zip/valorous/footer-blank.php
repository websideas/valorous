<?php
/**
 * The template for displaying the footer blank
 *
 *
 */
?>
</div><!-- #content -->
<?php wp_footer(); ?>

</body>
</html>
